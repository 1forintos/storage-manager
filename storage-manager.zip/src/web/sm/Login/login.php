<?php
	require_once "../db/auth.php";

	login();
?>